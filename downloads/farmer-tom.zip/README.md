# Farmer Tom

## About This Character

This premium pixel art character was created by **FoxHole Productions** for the Foxstead farming game and is available through the FoxHole Marketplace at [univershole.xyz](https://univershole.xyz).

## Contents

8-direction character with 8 static rotation poses and 4 full animation sets (Picking Up, Drinking, Chopping Tree, Fishing), each rendered across all 8 directions. 240 frames total.

## Usage & License

### Commercial License Included

This pack comes with a **full commercial license** allowing you to:

- Use in commercial games and projects
- Modify and edit the sprites
- Use in unlimited projects
- Sell games containing this character

### Restrictions

You may NOT:

- Resell or redistribute the raw character files
- Claim the artwork as your own creation
- Use in NFT projects without explicit permission

## Technical Specifications

- **Format**: PNG with transparency
- **Optimized For**: Top-down and isometric games
- **Style**: Pixel art

## Support

For support, questions, or custom character requests:

- **Website**: [univershole.xyz](https://univershole.xyz)
- **Re-download**: Connect the same wallet used for purchase to download again anytime

## Credits

**Created by FoxHole Productions**

(c) 2026 FoxHole Productions. All rights reserved.

---

Thank you for supporting independent pixel art creators!

*Character generated using PixelLab AI technology and curated by FoxHole Productions.*
