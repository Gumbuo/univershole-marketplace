﻿# Pixel Art Tileset Pack

## About This Pack

This premium pixel art tileset was created by **FoxHole Productions** using PixelLab AI technology and is available through the FoxHole Marketplace at [univershole.xyz](https://univershole.xyz).

## Contents

This pack includes:
- **Tileset PNG**: 4x4 grid of 16 Wang tiles (or 23 tiles with transitions) for seamless terrain creation
- **Metadata JSON**: Complete tileset configuration with tile coordinates and properties
- Ready for immediate use in game engines (Godot, Unity, GameMaker, etc.)

## What is a Wang Tileset?

Wang tilesets use corner-based autotiling for seamless terrain transitions:
- Each tile is defined by its 4 corner values
- Automatically blends between different terrain types
- Creates natural-looking terrain boundaries
- Perfect for top-down 2D games

## Usage & License

### Commercial License Included

This pack comes with a **full commercial license** allowing you to:

- Use in commercial games and projects
- Modify and edit the tiles
- Use in unlimited projects
- Sell games containing these tilesets

### Restrictions

You may NOT:

- Resell or redistribute the raw tileset files
- Claim the artwork as your own creation
- Use in NFT projects without explicit permission

## Technical Specifications

- **Format**: PNG tileset + JSON metadata
- **Tile Grid**: 4x4 (16 tiles) or 4x6 (23 tiles with transitions)
- **Optimized For**: Top-down 2D games
- **Style**: Pixel art with Wang tile autotiling support

## Integration Guide

### Using with Godot

1. Import the PNG file into your Godot project
2. Create a TileSet resource
3. Use the metadata.json for tile configuration
4. Set up autotiling using the Wang tile bitmask

### Using with Unity

1. Import the PNG as a sprite sheet
2. Use Unity's 2D Tilemap system
3. Configure tile rules based on the metadata.json
4. Enable autotiling for seamless terrain

### Using with GameMaker

1. Import the tileset PNG
2. Create a tileset asset
3. Configure autotiling rules from metadata.json
4. Use in your room editor

## Support

For support, questions, or custom tileset requests:

- **Website**: [univershole.xyz](https://univershole.xyz)
- **Re-download**: Connect the same wallet used for purchase to download again anytime

## Credits

**Created by FoxHole Productions**

(c) 2025 FoxHole Productions. All rights reserved.

---

Thank you for supporting independent pixel art creators!

*Tilesets generated using PixelLab AI technology and curated by FoxHole Productions.*
