﻿# Pixel Art Map Object Pack

## About This Pack

This premium pixel art object pack was created by **FoxHole Productions** using PixelLab AI technology and is available through the FoxHole Marketplace at [univershole.xyz](https://univershole.xyz).

## Contents

All objects in this pack are provided as PNG files with transparency, ready to use in your game projects.

## Usage & License

### Commercial License Included

This pack comes with a **full commercial license** allowing you to:

- Use in commercial games and projects
- Modify and edit the sprites
- Use in unlimited projects
- Sell games containing these objects

### Restrictions

You may NOT:

- Resell or redistribute the raw object files
- Claim the artwork as your own creation
- Use in NFT projects without explicit permission

## Technical Specifications

- **Format**: PNG with transparency
- **Optimized For**: Top-down and isometric games
- **Style**: Pixel art

## Support

For support, questions, or custom object requests:

- **Website**: [univershole.xyz](https://univershole.xyz)
- **Re-download**: Connect the same wallet used for purchase to download again anytime

## Credits

**Created by FoxHole Productions**

Â© 2025 FoxHole Productions. All rights reserved.

---

Thank you for supporting independent pixel art creators!

*Objects generated using PixelLab AI technology and curated by FoxHole Productions.*
