# Pixel Art Character Pack

## About This Character

This premium pixel art character was created by **FoxHole Productions** and is available through the FoxHole Marketplace at [univershole.xyz](https://univershole.xyz).

## Contents

This package includes:

- **8 Directional Rotations**: Character sprites facing all 8 directions (N, NE, E, SE, S, SW, W, NW)
- **18 Full Animation Sets**: Each animation includes all 8 directional variations
- **144 Total Animation Frames**: 18 animation types × 8 directions
- **Metadata File**: JSON file with character specifications
- **Preview Image**: Character preview/thumbnail

## Animation List

1. **backflip** - Acrobatic backflip maneuver
2. **breathing-idle** - Idle breathing animation
3. **cross-punch** - Cross punch attack
4. **fight-stance-idle-8-frames** - Combat ready stance
5. **fireball** - Projectile attack animation
6. **flying-kick** - Aerial kick attack
7. **getting-up** - Rising from ground
8. **high-kick** - High kick attack
9. **jumping-1** - Jump animation
10. **lead-jab** - Quick jab punch
11. **leg-sweep** - Low sweep attack
12. **roundhouse-kick** - Spinning kick
13. **running-8-frames** - Running movement
14. **surprise-uppercut** - Uppercut attack
15. **taking-punch** - Hit reaction
16. **throw-object** - Throwing animation
17. **two-footed-jump** - Double-foot jump
18. **walking-8-frames** - Walking movement

## File Structure

```
character-name/
├── rotations/
│   ├── north.png
│   ├── north-east.png
│   ├── east.png
│   ├── south-east.png
│   ├── south.png
│   ├── south-west.png
│   ├── west.png
│   └── north-west.png
├── animations/
│   ├── backflip/
│   │   ├── north/
│   │   │   ├── frame_000.png
│   │   │   ├── frame_001.png
│   │   │   └── ...
│   │   ├── north-east/
│   │   └── ... (all 8 directions)
│   ├── breathing-idle/
│   └── ... (all 18 animations)
├── preview.png
└── metadata.json
```

## Usage & License

### Commercial License Included

This character comes with a **full commercial license** allowing you to:

- ✅ Use in commercial games and projects
- ✅ Modify and edit the sprites
- ✅ Use in unlimited projects
- ✅ Sell games containing this character

### Restrictions

You may NOT:

- ❌ Resell or redistribute the raw character files
- ❌ Claim the artwork as your own creation
- ❌ Use in NFT projects without explicit permission

## Technical Specifications

- **Format**: PNG with transparency
- **Directions**: 8-way (N, NE, E, SE, S, SW, W, NW)
- **Animation Types**: 18 unique animations
- **Total Frames**: 144 (18 animations × 8 directions)
- **Optimized For**: Top-down and isometric games

## Support

For support, questions, or custom character requests:

- **Website**: [univershole.xyz](https://univershole.xyz)
- **Re-download**: Connect the same wallet used for purchase to download again anytime

## Credits

**Created by FoxHole Productions**

© 2025 FoxHole Productions. All rights reserved.

---

Thank you for supporting independent pixel art creators! 🎮

*Character generated using PixelLab AI technology and hand-refined by FoxHole Productions.*
